function check()
{
     var num=document.getElementById("input").value;
     function factorial(num)
     {
      if (num==1||num==0) {
          return num;
      } else {
          return num * factorial(num-1);
      }
     }
     var result=factorial(num);
     //document.getElementById("").innerHTML=result;
     var remove=result.toString();
     var regex=/[0]+$/;
     var after=remove.replace(regex,'');
     var len=after.length;
      if( len==2||len==1){
          var last=after.substr(len-2,len);
      }
      else{
        var last=after.substr(len-3,len);
      }
      document.getElementById("p1").innerHTML="Before remove Zero = "+result;
     document.getElementById("p2").innerHTML="After remove Zero= "+after;
     document.getElementById("p3").innerHTML="Last Digits= "+last;
     

}









